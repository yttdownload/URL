<!DOCTYPE html>
<html prefix="og:http://ogp.me/ns#" lang="en" class="load">
<head>
	<title>Downloading file castle-defense-2-v3.2.2-mod-5play.ru.apk</title>
<meta charset="utf-8">
<meta name="description" content="Downloading file castle-defense-2-v3.2.2-mod-5play.ru.apk">
<meta name="keywords" content="castle-defense-2-v3.2.2-mod-5play.ru.apk, castle-defense-2-v3.2.2-mod-5play.ru.apk for android">
<meta name="generator" content="DataLife Engine (https://dle-news.ru)">
<link rel="alternate" type="application/rss+xml" title="Download best Android games free | Modded games for android RSS" href="https://5play.org/en/rss.xml">
<link rel="preconnect" href="https://5play.org/" fetchpriority="high">
<meta property="twitter:card" content="summary">
<meta property="twitter:title" content="Downloading file castle-defense-2-v3.2.2-mod-5play.ru.apk">
<meta property="twitter:description" content="Downloading file castle-defense-2-v3.2.2-mod-5play.ru.apk">
<meta property="og:type" content="article">
<meta property="og:site_name" content="Download best Android games free | Modded games for android">
<meta property="og:title" content="Downloading file castle-defense-2-v3.2.2-mod-5play.ru.apk">
<meta property="og:description" content="Downloading file castle-defense-2-v3.2.2-mod-5play.ru.apk">
<meta name="HandheldFriendly" content="true">
<meta name="format-detection" content="telephone=no">
<meta name="viewport" content="initial-scale=1.0, width=device-width">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="default">
<meta name="mobile-web-app-capable" content="yes">
<meta name="google-site-verification" content="LGvz6uqmHQFqiPvBghNBOxuiTpRB_dIgePeiFliAqxg" />
<meta name="yandex-verification" content="5882ceeee565f7d0" />

<meta property="og:image" content="/templates/5ui/img/favicon/og_image.webp">

<link rel="apple-touch-icon" sizes="180x180" href="/templates/5ui/img/favicon/apple-touch-icon.png">
<link rel="shortcut icon" href="/templates/5ui/img/favicon/favicon.ico">
<link rel="icon" type="image/svg+xml" href="/templates/5ui/img/favicon/favicon.svg">
<link rel="icon" type="image/png" sizes="64x64" href="/templates/5ui/img/favicon/f64.png">
<link rel="icon" type="image/png" sizes="32x32" href="/templates/5ui/img/favicon/f32.png">
<link rel="icon" type="image/png" sizes="16x16" href="/templates/5ui/img/favicon/f16.png">

<link rel="prefetch" href="/templates/5ui/fonts/geologica-300.woff2" as="font" type="font/woff2" crossorigin>
<link rel="prefetch" href="/templates/5ui/fonts/geologica-500.woff2" as="font" type="font/woff2" crossorigin>
<link rel="preload" href="/templates/5ui/css/core.css?vj94z050" as="style">
<link rel="preload" href="/templates/5ui/css/header.css?vj94z046" as="style">
<link rel="preload" href="/templates/5ui/css/cdn.css?vj94z024" as="style">

<link rel="preload" as="script" href="/templates/5ui/js/darkmod.js?vj94z0">



<link href="/templates/5ui/css/core.css?vj94z050" type="text/css" rel="stylesheet">
<link href="/templates/5ui/css/header.css?vj94z046" type="text/css" rel="stylesheet">
<link href="/templates/5ui/css/cdn.css?vj94z024" type="text/css" rel="stylesheet">








<link href="/templates/5ui/css/cards.css?vj94z014" type="text/css" rel="stylesheet">


<link href="/templates/5ui/css/footer.css?vj94z04" type="text/css" rel="stylesheet">
<link href="/templates/5ui/css/login.css?vj94z05" type="text/css" rel="stylesheet">




<script src="/templates/5ui/js/darkmod.js?vj94z0"></script>


</head>
<body>
	 <header id="header-5p" class="header-first">
	<div class="wrp fc">
		<div class="head-l fc">
			
			<a class="logotype" href="/en/" title="5play">
	<span class="sr-only">5play</span>
	<svg width="100" height="36" viewBox="0 0 100 36" xmlns="http://www.w3.org/2000/svg">
		<g class="logo-icon">
			<path fill="#136e4b" d="M31.17,18l-1.35,1.4c-6.89,7.17-15.68,12.23-25.33,14.6l-1.89.47.09-.16c1.7-2.93,4.36-5.13,7.5-6.4,4.13-1.67,8-3.91,11.52-6.64,2.67-2.07,5.91-3.27,9.29-3.27h.18Z"/>
			<path fill="#fed14a" d="M31.17,18h-.17c-3.38,0-6.63-1.2-9.3-3.28-3.52-2.74-7.41-4.99-11.55-6.67-3.12-1.27-5.77-3.46-7.46-6.37l-.1-.18,1.89.5c9.66,2.37,18.44,7.43,25.33,14.6l1.35,1.4Z"/>
			<path fill="#17aa71" d="M2.6,1.5l-.54,1.87C-.69,12.93-.69,23.07,2.06,32.63l.54,1.87c1.72-2.98,2.37-6.43,1.9-9.83-.61-4.43-.61-8.93,0-13.36.48-3.39-.18-6.85-1.9-9.82Z"/>
			<path fill="#17aa71" d="M11.67,16.34c2.19,0,3.73,1.45,3.73,3.44s-1.58,3.56-3.66,3.56-3.66-1.47-3.67-3.48h2.27c.01.8.59,1.38,1.4,1.38s1.4-.62,1.4-1.46c0-.89-.64-1.52-1.55-1.52h-2.94l-.21-.28.59-5.29h5.66v2.01h-3.88l-.19,1.65h1.06-.01Z"/>
		</g>
		<path class="logo-text" fill="#17aa71" d="M45.66,9.16c4.62,0,8.03,3.45,8.03,8.1,0,4.65-3.41,8.12-8.03,8.12-1.59,0-3.03-.47-4.22-1.29v6.36h-4.14V9.59h2.74l.71,1.39c1.3-1.15,3-1.83,4.91-1.83h0ZM91.11,19.01l3.82-9.43h4.4l-6.68,15.12c-1.84,4.15-3.45,5.73-6.89,5.73h-1.71v-3.73h1.43c2,0,2.52-.53,3.46-2.85l.06-.12-6.49-14.15h4.51l4.09,9.43ZM71.78,9.17c1.97,0,3.71.69,5.04,1.87l.44-1.46h3.1s0,15.32,0,15.32h-3.25l-.36-1.37c-1.32,1.15-3.03,1.83-4.97,1.83-4.61,0-8.04-3.48-8.04-8.12s3.43-8.07,8.04-8.07ZM60.78,24.91h-4.14V4.07h4.14v20.84ZM45.32,13.06c-2.4,0-4.18,1.8-4.18,4.2,0,2.4,1.77,4.2,4.18,4.2s4.17-1.79,4.17-4.2c0-2.41-1.77-4.2-4.17-4.2ZM72.13,13.03c-2.41,0-4.18,1.8-4.18,4.2,0,2.4,1.77,4.2,4.18,4.2,2.41,0,4.17-1.79,4.17-4.2s-1.76-4.2-4.17-4.2Z"/>
	</svg>
</a>
			
			<div class="lang-sel fc">
				<button type="button" class="sel-lang__en active" onclick="location.href='https://5play.org/en/'" title="Английский"><span class="sr-only">Английский</span></button>
<button type="button" class="sel-lang__ru" onclick="location.href='https://5play.org/ru/'" title="Русский"><span class="sr-only">Русский</span></button>
				<span class="sr-only">Choose a language</span>
				<span class="lang-sel-border fc">
					<i class="lang-sel-ru" title="Ру"></i><i class="lang-sel-en" title="En"></i>
				</span>
			</div>
		</div>
		<div class="head-r fc">
			<a href="/index.php?do=search&lang=en" class="hbtn hbt qs-toggle" style="display: none;">
				<i class="im im-search"></i>
				<i class="im im-close"></i>
				<span class="sr-only">Find</span>
			</a>
			<button type="button" class="hbtn hbt mod-btn" id="mod-toggle" aria-label="Dark Mod">
				<i class="im im-sun"></i>
				<i class="im im-moon"></i>
			</button>
			
			<button class="hbtn huser hlogin dialog-btn" type="button" title="Authorization">
				<span class="sr-only">Authorization</span>
				<span class="mask"><i class="im im-login"></i></span>
			</button>
		</div>
	</div>
</header>
<div class="header-second wrp" id="header-tools">
	<div class="header-tools">
		<div class="hmenu fc">
			<nav class="hmenu-list fc" itemscope itemtype="http://schema.org/SiteNavigationElement">
				<a class="m-item" href="/en/android/games/" itemprop="url"><i class="im im-gamepad"></i><span class="m-item-cont" itemprop="name">Games</span></a>
				<a class="m-item" href="/en/android/apps/" itemprop="url"><i class="im im-apps"></i><span class="m-item-cont" itemprop="name">Apps</span></a>
				<a class="m-item" href="/en/top-100-best-android-games-apk.html" itemprop="url"><i class="im im-cup"></i><span class="m-item-cont" itemprop="name">TOP 100</span></a>
				<a class="m-item" href="/en/news/" itemprop="url"><i class="im im-bolt"></i><span class="m-item-cont" itemprop="name">News</span></a>
				<a class="m-item" href="/?do=orders&lang=en" style="display:none;"><i class="im im-addtopic"></i><span class="m-item-cont">Order table</span></a>
				<button id="mmenu-btn" type="button" class="m-item"><i class="im im-burger"></i><span class="m-item-cont">More</span></button>
				<div class="dropdown" style="display:none;">
					<button type="button" class="m-item dropdown-btn"><i class="im im-burger"></i><span class="m-item-cont">More</span></button>
					<div class="dropdown-box" style="display: none;">
						<nav class="hmenu-sub-list">
							<a class="m-item" href="/?do=orders&lang=en"><i class="im im-addtopic"></i><span class="m-item-cont">Order table</span></a>
						</nav>
						
					</div>
				</div>
				<a href="/index.php?do=search&lang=en" class="m-item qs-toggle" style="display:none;">
					<i class="im im-search"></i>
					<span class="sr-only">Find</span>
				</a>
			</nav>
		</div>
		<form class="qs-form fc" id="qs-form" class="qs" method="get" action="/index.php?do=search&lang=en" style="display: none;">
			<div class="qs-control">
				<label class="qs-label sr-only" for="story">Find</label>
				<input class="qs-input" id="story" name="story" placeholder="Find a game or program" type="search">
				<button class="qs-btn" type="submit" title="Find" aria-label="Find">
					<i class="im im-search"></i>
				</button>
				<button type="button" class="qs-toggle" aria-label="Close Search">
					<i class="im im-close"></i>
				</button>
			</div>
			<input type="hidden" name="lang" value="en">
<input type="hidden" name="do" value="search">
			<input type="hidden" name="subaction" value="search">
			<input type="hidden" name="titleonly" id="titleonly" value="0">
		</form>
	</div>
</div>
	 
	
	 
	 
	 
	 
	 
	 <main class="content-5p">
	<section class="page-cdn">
		<div class="wrp">
			
			


<figure class="appicon">
  <img width="200" height="200" src="https://cdn.5play.org/posts/2017-10/1508420627_1.png" alt="Download Castle Defense 2" fetchpriority="high">	
  <i class="mask star-mask"></i>
</figure>
<div class="md5">MD5: 87e75ce98549cbe19b81fce9829d5221</div>
<h1 class="title">Download castle-defense-2-v3.2.2-mod-5play.ru.apk</h1>
<ul class="cdn-meta">
  <li class="cdn-meta-item">v3.2.2</li>
  <li class="cdn-meta-item">Android 2.3.3</li>
</ul>
<div id="page-cdn-btns" class="btn-group counter-active">
  <a class="btn btn-fill btn-blue" href="https://t.me/+Scv8Dj0LIrw5M2E6" target="_blank" rel="nofollow noopener">
    <span class="btn-cont">Download from Telegram</span>
  </a>
  <a href="https://s1.5playdisk.com/e367f91654c92824f3c500b4b22101a8:2026051316/files/castle-defense-2-v3.2.2-mod-5play.ru.apk" id="btn-download-cdn" class="btn btn-fill offcounter" data-title="Loading..." style="display:none;">
    <span class="btn-cont">Download (34.1 Mb)</span>
  </a>
  <a href="/en/" class="btn btn-line offcounter" style="display:none;">
    <span class="btn-cont">Back to Description</span>
  </a>
  <div class="download-counter btn" style="--counter-progress: 0%;"><span class="btn-cont">Wait <span class="download-counter-num">10</span> sec</span></div>
</div>
			<div class="faq-list">
				<a class="link-faq" href="/en/download-help.html"><span>Can't download?</span><i class="im im-kright"></i></a>
				<a class="link-faq" href="/en/ustanovka-igr-i-programm-na-android.html"><span>Installing games and programs</span><i class="im im-kright"></i></a>
				<a class="link-faq" href="/en/ustanovka-igr-s-keshem-na-android.html"><span>Installing games with a cache</span><i class="im im-kright"></i></a>
				<a class="link-faq" href="/en/kak-sdelat-skrinshot-na-android.html"><span>How to make a screenshot</span><i class="im im-kright"></i></a>
				<a class="link-faq" href="/en/how-to-install-apks.html"><span>How to install APKS</span><i class="im im-kright"></i></a>
			</div>
		</div>
	</section>
	<section class="sect sect-more">
		<div class="wrp">
			<h2 class="sect-head title">Recommend</h2>
			<div class="glist cards-sw g4 hscroll">
				<div class="card appdesc item">
    <div class="card-first-cont">
        
        <figure class="appicon"><img width="64" height="64" src="https://cdn.5play.org/posts/2026-05/1778579188_1.webp" alt="Toca Boca World" loading="lazy"></figure>
        <a href="https://5play.org/en/7591-toca-life-world.html" class="item-link title">Toca Boca World</a>
        <div class="desc">Developing game for Android, which brought together all the worlds and locations of a series of</div>
    </div>
    <div class="card-sec-cont">
        <a href="https://5play.org/en/7591-toca-life-world.html" class="btn btn-line btn-sm"><span class="btn-cont">Download</span></a>
    </div>
</div><div class="card appdesc item">
    <div class="card-first-cont">
        
        <figure class="appicon"><img width="64" height="64" src="https://cdn.5play.org/posts/2024-10/1728293614_1.webp" alt="Brawl Stars" loading="lazy"></figure>
        <a href="https://5play.org/en/7353-brawl-stars.html" class="item-link title">Brawl Stars</a>
        <div class="desc">Multiplayer action with role-playing elements and dynamic battle between the teams 3-on-3.</div>
    </div>
    <div class="card-sec-cont">
        <a href="https://5play.org/en/7353-brawl-stars.html" class="btn btn-line btn-sm"><span class="btn-cont">Download</span></a>
    </div>
</div><div class="card appdesc item">
    <div class="card-first-cont">
        
        <figure class="appicon"><img width="64" height="64" src="https://cdn.5play.org/posts/2025-10/3de8b6b152_1.webp" alt="TikTok" loading="lazy"></figure>
        <a href="https://5play.org/en/10913-tiktok.html" class="item-link title">TikTok</a>
        <div class="desc">App to create short videos on various themes with huge user base.</div>
    </div>
    <div class="card-sec-cont">
        <a href="https://5play.org/en/10913-tiktok.html" class="btn btn-line btn-sm"><span class="btn-cont">Download</span></a>
    </div>
</div><div class="card appdesc item">
    <div class="card-first-cont">
        
        <figure class="appicon"><img width="64" height="64" src="https://cdn.5play.org/posts/2025-12/fe5502ad69_1.webp" alt="5PLAY App" loading="lazy"></figure>
        <a href="https://5play.org/en/21214-5play-app.html" class="item-link title">5PLAY App</a>
        <div class="desc">The official client for 5play.org is a straightforward way to reach the content you need without</div>
    </div>
    <div class="card-sec-cont">
        <a href="https://5play.org/en/21214-5play-app.html" class="btn btn-line btn-sm"><span class="btn-cont">Download</span></a>
    </div>
</div>
			</div>
		</div>
	</section>
</main>
<script>
	document.addEventListener("DOMContentLoaded", () => {
		
		const container = document.getElementById("page-cdn-btns");
		const counterBlock = container.querySelector(".download-counter");
		const counterNum = counterBlock.querySelector(".download-counter-num");
		const offCounters = container.querySelectorAll(".offcounter");
		
		const totalTime = 10;
		let count = totalTime;

		counterNum.textContent = count;
		counterBlock.style.setProperty("--counter-progress", "0%");

		const interval = setInterval(() => {
			count--;

			const rawPercent = ((totalTime - count) / totalTime) * 100;
			const percent = Math.min(100, Math.round(rawPercent));
			counterBlock.style.setProperty("--counter-progress", percent + "%");
			counterNum.textContent = Math.max(count, 0);

			if (count < 0) {
				clearInterval(interval);
				setTimeout(() => {
					container.classList.remove("counter-active");
					offCounters.forEach(el => el.style.removeProperty("display"));
				}, 50);
			}
		}, 1000);
		
		const downloadBtn = document.getElementById("btn-download-cdn");
		if (downloadBtn) {
			downloadBtn.addEventListener("click", () => {
				downloadBtn.classList.add("downloading");
			});
		}
	});
</script>
	 <footer id="footer-5p" class="footer-5p">
	<div class="wrp">
		
		
		<a class="f-telegram footblock" href="https://t.me/+NuCc8y6KVbAyYmFi" target="_blank" rel="nofollow noopener">
			<span class="title">Our Telegram</span>
			<span class="desc">Stay up to date with the latest updates</span>
			<i class="f-telegram-icon"><img width="324" height="307" src="https://cdn.5play.org/assets/pic/f-telegram-icon.webp" srcset="https://cdn.5play.org/assets/pic/f-telegram-icon.webp, https://cdn.5play.org/assets/pic/f-telegram-icon-2x.webp 2x" alt=""></i>
			<span class="btn btn-fill btn-blue btn-sm"><span class="btn-cont">Join Now</span></span>
		</a>
		<div class="fmenu">
			<nav class="fmenu-list">
				<a class="ms-item" href="/?do=feedback&lang=en">Feedback</a>
				<a class="ms-item" href="/en/copyright.html">Terms of use</a>
				<a class="ms-item" href="/en/disclaimer.html">DMCA</a>
				<a class="ms-item" href="/en/pravoobl.html">Copyright Holders</a>
				<a class="ms-item" href="/en/политика-конфиденциальности.html">Privacy Policy</a>
			</nav>
		</div>
		<div class="foot-info fc">
			<a href="/en/" class="foot-logo"><img width="32" height="32" src="/templates/5ui/img/icons/5play-color.svg" alt="5play.org" loading="lazy"></a>
			<div class="copyright"><span>2016-2026 © 5play.org</span> <span>Games and apps for android</span></div>
			<a id="scroll-up" class="scroll-up" href="#header-5p" role="button" title="Scroll up" aria-label="Scroll up">
				<span class="sr-only">Scroll up</span>
				<i class="im im-aup"></i>
			</a>
		</div>
	</div>
</footer>
	

<div class="modal-overlay" id="modalOverlay" style="display: none;" aria-hidden="true">
	<div class="modal-inner">
		<div class="modal modal-side" id="modal">
			<button class="close-btn" id="closeModal" aria-label="Close"><i class="im im-close"></i></button>
			<div class="modal-side-pic">
				<i class="modal-logo im im-5play"></i>
				<figure class="cover">
					<img width="320" height="516" src="https://cdn.5play.org/assets/pic/login-5play.webp" srcset="https://cdn.5play.org/assets/pic/login-5play.webp, https://cdn.5play.org/assets/pic/login-5play-2x.webp 2x" alt="5play">
				</figure>
			</div>
			<form class="modal-cont modal-cont-pad form-list" method="post">
				<h3 class="title">Login to 5play.org</h3>
				<div class="form-group">
					<div class="form-group-label"><label for="login_name">Login</label></div>
					<input class="form-control" type="text" id="login_name" name="login_name" required>
				</div>
				<div class="form-group">
					<div class="form-group-label">
						<label for="login_password">Password</label>
						<a class="right link" href="https://5play.org/index.php?do=lostpassword&lang=en">Forgot your password?</a>
					</div>
					<input class="form-control" type="password" id="login_password" name="login_password" required>
				</div>
				<div class="form-submit btn-group">
					<button class="btn btn-fill btn-block" onclick="submit();" type="submit"><span class="btn-cont">Login</span></button>
					<a href="https://5play.org/index.php?do=register&lang=en" class="btn btn-link btn-block"><span class="btn-cont">Registration</span></a>
				</div>
				<div class="sep-text"><span title="Or log in via"></span></div>
				<div class="social-links fc">
					<a class="soc-item" href="https://www.facebook.com/dialog/oauth?client_id=281507214574045&amp;redirect_uri=https%3A%2F%2F5play.org%2Findex.php%3Fdo%3Dauth-social%26provider%3Dfc&amp;scope=public_profile%2Cemail&amp;display=popup&amp;state=4abf342b86295ea446a19f7b3e0c4a3b&amp;response_type=code" target="_blank" rel="nofollow noopener"><img width="32" height="32" src="/templates/5ui/img/social/facebook.svg" alt="Facebook" title="Facebook"></a>
					<a class="soc-item" href="https://accounts.google.com/o/oauth2/auth?client_id=609340283350-apppi0njujq31fe388ckhmtvsv9optgk.apps.googleusercontent.com&amp;redirect_uri=https%3A%2F%2F5play.org%2Findex.php%3Fdo%3Dauth-social%26provider%3Dgoogle&amp;scope=https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fuserinfo.email+https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fuserinfo.profile&amp;state=4abf342b86295ea446a19f7b3e0c4a3b&amp;response_type=code" target="_blank" rel="nofollow noopener"><img width="32" height="32" src="/templates/5ui/img/social/google.svg" alt="Google" title="Google"></a>
				</div>
				<input name="login" type="hidden" id="login" value="submit">
			</form>
		</div>
	</div>
</div>

	
	 <div id="mobilemenu" class="mobilemenu" style="display:none;">
	<button class="close-btn" id="mmenu-close" aria-label="Close"><i class="im im-close"></i></button>
	<div class="mobilemenu-cont">
		<nav class="mmenu-list">
			<a class="m-item" href="/en/android/games/" itemprop="url"><i class="im im-gamepad"></i><span class="m-item-cont" itemprop="name">Games</span></a>
			<a class="m-item" href="/en/android/apps/" itemprop="url"><i class="im im-apps"></i><span class="m-item-cont" itemprop="name">Apps</span></a>
			<a class="m-item" href="/en/top-100-best-android-games-apk.html" itemprop="url"><i class="im im-cup"></i><span class="m-item-cont" itemprop="name">TOP 100</span></a>
			<a class="m-item" href="/en/news/" itemprop="url"><i class="im im-bolt"></i><span class="m-item-cont" itemprop="name">News</span></a>
			<a class="m-item" href="/?do=orders&lang=en"><i class="im im-addtopic"></i><span class="m-item-cont">Order table</span></a>
		</nav>
		<nav class="mmenu-sublist">
			<a class="ms-item" href="/?do=feedback&lang=en">Feedback</a>
			<a class="ms-item" href="/en/copyright.html">Terms of use</a>
			<a class="ms-item" href="/en/disclaimer.html">DMCA</a>
			<a class="ms-item" href="/en/pravoobl.html">Copyright Holders</a>
			<a class="ms-item" href="/en/политика-конфиденциальности.html">Privacy Policy</a>
		</nav>
	</div>
</div>
	 <script>
	window.addEventListener('load', function () { document.documentElement.classList.remove('load'); });
</script>


<script src="/engine/classes/js/jquery3.js?v=j94z0"></script>
<script src="/engine/classes/js/jqueryui3.js?v=j94z0" defer></script>
<script src="/engine/classes/js/dle_js.js?v=j94z0" defer></script>
<script>
<!--
var dle_root       = '/';
var dle_admin      = '';
var dle_login_hash = '57720c44e49783a8a482b6975959745ed7da9eda';
var dle_group      = 5;
var dle_link_type  = 1;
var dle_skin       = '5ui';
var dle_wysiwyg    = 0;
var dle_min_search = '3';
var dle_act_lang   = ["Yes", "Cancel", "Enter", "Cancel", "Save", "Delete", "Loading. Please, wait..."];
var menu_short     = 'Quick edit';
var menu_full      = 'Full edit';
var menu_profile   = 'View profile';
var menu_send      = 'Send message';
var menu_uedit     = 'Admin Center';
var dle_info       = 'Information';
var dle_confirm    = 'Confirm';
var dle_prompt     = 'Enter the information';
var dle_req_field  = ["Fill the name field", "Fill the message field", "Fill the field with the subject of the message"];
var dle_del_agree  = 'Are you sure you want to delete it? This action cannot be undone';
var dle_spam_agree = 'Are you sure you want to mark the user as a spammer? This will remove all his comments';
var dle_c_title    = 'Send a complaint';
var dle_complaint  = 'Enter the text of your complaint to the Administration:';
var dle_mail       = 'Your e-mail:';
var dle_big_text   = 'Highlighted section of text is too large.';
var dle_orfo_title = 'Enter a comment to the detected error on the page for Administration ';
var dle_p_send     = 'Send';
var dle_p_send_ok  = 'Notification has been sent successfully ';
var dle_save_ok    = 'Changes are saved successfully. Refresh the page?';
var dle_reply_title= 'Reply to the comment';
var dle_tree_comm  = '0';
var dle_del_news   = 'Delete article';
var dle_sub_agree  = 'Do you really want to subscribe to this article’s comments?';
var dle_unsub_agree  = 'Do you really want to unsubscribe from comments on this publication?';
var dle_captcha_type  = '4';
var dle_share_interesting  = ["Share a link to the selected text", "Twitter", "Facebook", "Вконтакте", "Direct Link:", "Right-click and select «Copy Link»"];
var DLEPlayerLang     = {prev: 'Previous',next: 'Next',play: 'Play',pause: 'Pause',mute: 'Mute', unmute: 'Unmute', settings: 'Settings', enterFullscreen: 'Enable full screen mode', exitFullscreen: 'Disable full screen mode', speed: 'Speed', normal: 'Normal', quality: 'Quality', pip: 'PiP mode'};
var DLEGalleryLang    = {CLOSE: 'Close (Esc)', NEXT: 'Next Image', PREV: 'Previous image', ERROR: 'Warning! An error was detected', IMAGE_ERROR: 'Failed to load image', TOGGLE_SLIDESHOW: 'Watch slideshow (space) ',TOGGLE_FULLSCREEN: 'Full-screen mode', TOGGLE_THUMBS: 'Turn on / Turn off thumbnails', ITERATEZOOM: 'Increase / Reduce', DOWNLOAD: 'Download image' };
var DLEGalleryMode    = 0;
var DLELazyMode       = 2;
var allow_dle_delete_news   = false;
var dle_search_delay   = false;
var dle_search_value   = '';
jQuery(function($){
FastSearch();
});
//-->
</script>

<script src="/templates/5ui/js/lib.js?vj94z08"></script>
<script src="/templates/5ui/js/modal.js?vj94z0"></script>







    
	  
<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-TS73N6ZFZC"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-TS73N6ZFZC');
</script>
 
</body>
</html>
<!-- DataLife Engine Copyright SoftNews Media Group (https://dle-news.ru) -->
